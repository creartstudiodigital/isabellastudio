import { useEffect, useRef } from "react";
import { citaTotal, citaWhatsAppUrl, fmtPrice, type CitaItem } from "@/lib/salon";
import { img } from "@/lib/salon-images";
import { Icon } from "./Icons";

type Props = { open: boolean; items: CitaItem[]; onClose: () => void; onRemove: (name: string) => void };

/** Side drawer listing the chosen services, the estimated total and the WhatsApp send button. */
export function CitaDrawer({ open, items, onClose, onRemove }: Props) {
  const closeRef = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    if (open) closeRef.current?.focus();
  }, [open]);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <>
      <div className="scrim" hidden={!open} onClick={onClose} />
      <aside className={`drawer${open ? " open" : ""}`} aria-label="Mi cita" aria-hidden={!open}>
        <header>
          <h3>Mi <span className="script">cita</span></h3>
          <button className="x" ref={closeRef} aria-label="Cerrar" onClick={onClose}><Icon id="close" /></button>
        </header>
        <div className="citems">
          {items.length === 0 ? (
            <div className="empty-c">
              <img src={img("logo-magenta")} alt="" />
              Aún no agregas servicios.<br />Pulsa + en el menú de precios.
            </div>
          ) : (
            items.map((i) => (
              <div className="citem" key={i.name}>
                <span>{i.name}</span>
                <b>{fmtPrice(i.price, i.cur)}</b>
                <button aria-label={`Quitar ${i.name}`} onClick={() => onRemove(i.name)}><Icon id="close" /></button>
              </div>
            ))
          )}
        </div>
        <div className="total"><span>Total estimado</span><b>{citaTotal(items)}</b></div>
        <a className="btn btn-mag" href={citaWhatsAppUrl(items)} target="_blank" rel="noopener"><Icon id="wa" />Enviar cita por WhatsApp</a>
        <p className="fine">Te confirmamos fecha y hora por WhatsApp. Puedes pagar con Cashea.</p>
      </aside>
    </>
  );
}
