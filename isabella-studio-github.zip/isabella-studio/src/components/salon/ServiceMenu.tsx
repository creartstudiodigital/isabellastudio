import type { ReactNode } from "react";
import { CATS, norm, serviceCount, waLink, type Service } from "@/lib/salon";
import { Icon } from "./Icons";

type Props = {
  cur: string;
  query: string;
  onSelect: (id: string) => void;
  onQuery: (q: string) => void;
  isOn: (name: string) => boolean;
  onToggle: (name: string, price: number) => void;
};

function Highlight({ name, q }: { name: string; q: string }) {
  if (!q) return <>{name}</>;
  const i = norm(name).indexOf(q);
  if (i < 0) return <>{name}</>;
  return (
    <>
      {name.slice(0, i)}
      <mark>{name.slice(i, i + q.length)}</mark>
      {name.slice(i + q.length)}
    </>
  );
}

function Row({ s, q, isOn, onToggle }: { s: Service; q: string } & Pick<Props, "isOn" | "onToggle">) {
  const [n, p] = s;
  const on = isOn(n);
  return (
    <div className="row">
      <span className="n"><Highlight name={n} q={q} /></span>
      <span className="p">{p} €</span>
      <button className="add" aria-pressed={on} aria-label={`${on ? "Quitar" : "Agregar"} ${n}`} onClick={() => onToggle(n, p)}>
        <Icon id={on ? "check" : "plus"} />
      </button>
    </div>
  );
}

/** Price menu with category tabs, accent-insensitive search and + buttons that build the cita. */
export function ServiceMenu({ cur, query, onSelect, onQuery, isOn, onToggle }: Props) {
  const q = norm(query.trim());
  const cat = CATS.find((c) => c.id === cur) ?? CATS[0];

  let panel: ReactNode;
  if (q) {
    const groups = CATS.flatMap((c) =>
      c.groups
        .map(([g, it]) => ({ key: `${c.id}-${g}`, g, cname: c.name, items: it.filter(([n]) => norm(n).includes(q)) }))
        .filter((x) => x.items.length),
    );
    panel = groups.length ? (
      groups.map((x) => (
        <div className="grp" key={x.key}>
          <h3>{x.g} <small>{x.cname}</small></h3>
          <div className="rows">{x.items.map((s) => <Row key={s[0]} s={s} q={q} isOn={isOn} onToggle={onToggle} />)}</div>
        </div>
      ))
    ) : (
      <p className="none">
        No encontramos “{query}”.{" "}
        <a href={waLink("Hola, busco el servicio: " + query)} target="_blank" rel="noopener">Pregúntanos por WhatsApp</a>.
      </p>
    );
  } else if (cat) {
    panel = cat.groups.map(([g, it]) => (
      <div className="grp" key={g}>
        <h3>{g} <small>{it.length} servicios</small></h3>
        <div className="rows">{it.map((s) => <Row key={s[0]} s={s} q="" isOn={isOn} onToggle={onToggle} />)}</div>
      </div>
    ));
  }

  return (
    <div className="menu">
      <div>
        <label className="searchbox">
          <Icon id="search" />
          <input type="search" placeholder="Buscar servicio…" aria-label="Buscar servicio" value={query} onChange={(e) => onQuery(e.target.value)} />
        </label>
        <div className="side" role="tablist">
          {CATS.map((c) => (
            <button key={c.id} role="tab" aria-selected={!query && c.id === cur} onClick={() => onSelect(c.id)}>
              {c.name}
              <span>{serviceCount(c)}</span>
            </button>
          ))}
        </div>
      </div>
      <div className="panel">{panel}</div>
    </div>
  );
}
