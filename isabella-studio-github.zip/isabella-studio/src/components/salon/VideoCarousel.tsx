import { useEffect, useRef, useState } from "react";
import { VIDEOS } from "@/lib/salon-videos";

const N = VIDEOS.length;

/** Swipeable reel carousel: visible videos play muted on loop; tap a video to turn its sound on. */
export function VideoCarousel() {
  const trackRef = useRef<HTMLDivElement>(null);
  const [idx, setIdx] = useState(0);
  const [sound, setSound] = useState<number | null>(null);

  useEffect(() => {
    const tr = trackRef.current;
    if (!tr) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const vids = Array.from(tr.querySelectorAll("video"));
    const io = new IntersectionObserver(
      (es) =>
        es.forEach((e) => {
          const v = e.target as HTMLVideoElement;
          if (e.isIntersecting && e.intersectionRatio > 0.6 && !reduced) v.play().catch(() => {});
          else v.pause();
        }),
      { root: tr, threshold: [0, 0.6, 1] },
    );
    vids.forEach((v) => io.observe(v));
    let st: ReturnType<typeof setTimeout> | undefined;
    const onScroll = () => {
      clearTimeout(st);
      st = setTimeout(() => {
        const cards = Array.from(tr.children) as HTMLElement[];
        const x = tr.scrollLeft;
        let b = 0;
        let bd = 1e9;
        cards.forEach((c, k) => {
          const d = Math.abs(c.offsetLeft - x);
          if (d < bd) {
            bd = d;
            b = k;
          }
        });
        if (x >= tr.scrollWidth - tr.clientWidth - 4) b = N - 1;
        setIdx(b);
      }, 80);
    };
    tr.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      io.disconnect();
      clearTimeout(st);
      tr.removeEventListener("scroll", onScroll);
    };
  }, []);

  const go = (i: number) => {
    const tr = trackRef.current;
    const k = (i + N) % N;
    const c = tr?.children[k] as HTMLElement | undefined;
    if (!tr || !c) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    tr.scrollTo({ left: Math.min(c.offsetLeft, tr.scrollWidth - tr.clientWidth), behavior: reduced ? "auto" : "smooth" });
    setIdx(k);
  };

  const toggleSound = (i: number) => {
    const tr = trackRef.current;
    if (!tr) return;
    const vids = Array.from(tr.querySelectorAll("video"));
    const on = sound !== i;
    vids.forEach((v, k) => {
      v.muted = !(on && k === i);
    });
    const v = vids[i];
    if (on && v) v.play().catch(() => {});
    setSound(on ? i : null);
  };

  return (
    <div className="vcar" aria-roledescription="carrusel" aria-label="Videos de Isa'Bella Studio">
      <div className="vcar-track" ref={trackRef}>
        {VIDEOS.map((v, i) => (
          <figure className="vslide" key={v.src} aria-label={`Video ${i + 1} de ${N}: ${v.caption}`}>
            <video src={v.src} poster={v.poster} muted loop playsInline preload="metadata" onClick={() => toggleSound(i)} />
            <figcaption>{v.caption}</figcaption>
            <button
              className={`vsound${sound === i ? " on" : ""}`}
              aria-label={sound === i ? "Silenciar video" : "Activar sonido"}
              onClick={() => toggleSound(i)}
            >
              {sound === i ? (
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M4 9h4l5-4v14l-5-4H4z" /><path d="M16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12" /></svg>
              ) : (
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M4 9h4l5-4v14l-5-4H4z" /><path d="M17 9.5l5 5M22 9.5l-5 5" /></svg>
              )}
            </button>
          </figure>
        ))}
      </div>
      <div className="car-nav">
        <button className="car-btn" aria-label="Video anterior" onClick={() => go(idx - 1)}>
          <svg viewBox="0 0 24 24"><path fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" d="M15 5l-7 7 7 7" /></svg>
        </button>
        <div className="car-dots">
          {VIDEOS.map((v, i) => (
            <button key={v.src} className={i === idx ? "on" : undefined} aria-label={`Ir al video ${i + 1}`} onClick={() => go(i)} />
          ))}
        </div>
        <span className="car-count">{idx + 1} / {N}</span>
        <button className="car-btn" aria-label="Video siguiente" onClick={() => go(idx + 1)}>
          <svg viewBox="0 0 24 24"><path fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" d="M9 5l7 7-7 7" /></svg>
        </button>
      </div>
    </div>
  );
}
