import { useEffect, useRef, useState } from "react";
import { HERO_SLIDES } from "@/lib/salon";
import { img } from "@/lib/salon-images";

const N = HERO_SLIDES.length;

/** Swipe/drag photo carousel with dots, arrows, keyboard and 4s auto-advance. */
export function HeroCarousel() {
  const trackRef = useRef<HTMLDivElement>(null);
  const [idx, setIdx] = useState(0);
  const api = useRef<{ go: (i: number) => void; idx: number }>({ go: () => {}, idx: 0 });

  useEffect(() => {
    const tr = trackRef.current;
    if (!tr) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const slides = () => Array.from(tr.children) as HTMLElement[];
    const maxL = () => tr.scrollWidth - tr.clientWidth;
    let timer: ReturnType<typeof setInterval> | undefined;
    let st: ReturnType<typeof setTimeout> | undefined;

    const mark = (i: number) => {
      api.current.idx = i;
      setIdx(i);
    };
    const go = (i: number) => {
      const k = (i + N) % N;
      const s = slides()[k];
      if (!s) return;
      tr.scrollTo({ left: Math.min(s.offsetLeft, maxL()), behavior: reduced ? "auto" : "smooth" });
      mark(k);
    };
    const nearest = () => {
      const x = tr.scrollLeft;
      if (x >= maxL() - 4) return N - 1;
      let b = 0;
      let bd = 1e9;
      slides().forEach((s, k) => {
        const d = Math.abs(s.offsetLeft - x);
        if (d < bd) {
          bd = d;
          b = k;
        }
      });
      return b;
    };
    const stop = () => clearInterval(timer);
    const restart = () => {
      stop();
      if (!reduced) timer = setInterval(() => go(api.current.idx + 1), 4000);
    };
    api.current.go = (i) => {
      go(i);
      restart();
    };

    const onScroll = () => {
      clearTimeout(st);
      st = setTimeout(() => mark(nearest()), 80);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight") api.current.go(api.current.idx + 1);
      if (e.key === "ArrowLeft") api.current.go(api.current.idx - 1);
    };
    let down = false;
    let sx = 0;
    let sl0 = 0;
    let moved = 0;
    const onDown = (e: PointerEvent) => {
      if (e.pointerType !== "mouse") return;
      down = true;
      moved = 0;
      sx = e.clientX;
      sl0 = tr.scrollLeft;
      tr.classList.add("drag");
      tr.setPointerCapture(e.pointerId);
      stop();
    };
    const onMove = (e: PointerEvent) => {
      if (!down) return;
      const dx = e.clientX - sx;
      moved = Math.abs(dx);
      tr.scrollLeft = sl0 - dx;
    };
    const onUp = () => {
      if (!down) return;
      down = false;
      tr.classList.remove("drag");
      const dx = tr.scrollLeft - sl0;
      let t = nearest();
      if (moved > 40 && t === api.current.idx) t = api.current.idx + (dx > 0 ? 1 : -1);
      go(Math.max(0, Math.min(N - 1, t)));
      restart();
    };
    const onLeave = () => {
      if (!down) restart();
    };

    tr.addEventListener("scroll", onScroll, { passive: true });
    tr.addEventListener("keydown", onKey);
    tr.addEventListener("pointerdown", onDown);
    tr.addEventListener("pointermove", onMove);
    tr.addEventListener("pointerup", onUp);
    tr.addEventListener("pointercancel", onUp);
    tr.addEventListener("touchstart", stop, { passive: true });
    tr.addEventListener("touchend", restart, { passive: true });
    tr.addEventListener("mouseenter", stop);
    tr.addEventListener("mouseleave", onLeave);
    restart();

    return () => {
      stop();
      clearTimeout(st);
      tr.removeEventListener("scroll", onScroll);
      tr.removeEventListener("keydown", onKey);
      tr.removeEventListener("pointerdown", onDown);
      tr.removeEventListener("pointermove", onMove);
      tr.removeEventListener("pointerup", onUp);
      tr.removeEventListener("pointercancel", onUp);
      tr.removeEventListener("touchstart", stop);
      tr.removeEventListener("touchend", restart);
      tr.removeEventListener("mouseenter", stop);
      tr.removeEventListener("mouseleave", onLeave);
    };
  }, []);

  return (
    <div className="car" aria-roledescription="carrusel" aria-label="Trabajos de Isa'Bella Studio">
      <div className="car-track" ref={trackRef} tabIndex={0}>
        {HERO_SLIDES.map(([f, c], i) => (
          <figure className="slide" key={f} aria-label={`${i + 1} de ${N}`}>
            <img src={img(f)} alt={c} loading={i > 2 ? "lazy" : "eager"} draggable={false} />
            <figcaption>{c}</figcaption>
          </figure>
        ))}
      </div>
      <div className="car-nav">
        <button className="car-btn" aria-label="Foto anterior" onClick={() => api.current.go(api.current.idx - 1)}>
          <svg viewBox="0 0 24 24"><path fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" d="M15 5l-7 7 7 7" /></svg>
        </button>
        <div className="car-dots">
          {HERO_SLIDES.map(([f], i) => (
            <button key={f} className={i === idx ? "on" : undefined} aria-label={`Ir a la foto ${i + 1}`} onClick={() => api.current.go(i)} />
          ))}
        </div>
        <span className="car-count">{idx + 1} / {N}</span>
        <button className="car-btn" aria-label="Foto siguiente" onClick={() => api.current.go(api.current.idx + 1)}>
          <svg viewBox="0 0 24 24"><path fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" d="M9 5l7 7-7 7" /></svg>
        </button>
      </div>
    </div>
  );
}
