// SVG sprite from the original site; <Icon id="wa" /> references a symbol by id.
// The z-* symbols are the laser zone pictograms (bozo, axilas, bikini, piernas, muslos).
// Stroke attributes live inside each symbol: <use> clones the symbol into its own
// shadow tree, so presentation attributes on an ancestor of the symbol would not apply.
export type IconId =
  | "wa" | "tt" | "ig" | "pin" | "bag" | "plus" | "check" | "close" | "search" | "arrow" | "play"
  | "z-bozo" | "z-axilas" | "z-bikini" | "z-piernas" | "z-muslos";

const ZONE_STROKE = { fill: "none", stroke: "currentColor", strokeWidth: 1.5, strokeLinecap: "round", strokeLinejoin: "round" } as const;

export function Icon({ id }: { id: IconId }) {
  return (
    <svg aria-hidden="true">
      <use href={`#${id}`} />
    </svg>
  );
}

export function SvgSprite() {
  return (
    <svg width="0" height="0" style={{ position: "absolute" }} aria-hidden="true">
      <symbol id="wa" viewBox="0 0 24 24"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2c-1.5 0-3-.4-4.3-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8-.2-.1-.4-.1-.6.1l-.8 1c-.1.2-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.3-.4.2-.4.7-1.3.1-.2 0-.3 0-.4l-.8-1.8c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2c0 1.3.9 2.5 1.1 2.7.1.2 1.8 2.8 4.4 3.9 1.6.7 2.3.8 3.1.6.5-.1 1.5-.6 1.7-1.2.2-.6.2-1.1.2-1.2-.1-.1-.3-.2-.5-.3z" /></symbol>
      <symbol id="tt" viewBox="0 0 24 24"><path fill="currentColor" d="M16.6 5.8A4.3 4.3 0 0 1 15.5 3h-3.1v12.4a2.6 2.6 0 1 1-1.8-2.5V9.7a5.7 5.7 0 1 0 4.9 5.7V9a7.4 7.4 0 0 0 4.3 1.4V7.3a4.3 4.3 0 0 1-3.2-1.5z" /></symbol>
      <symbol id="ig" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" strokeWidth="1.8"><rect x="3" y="3" width="18" height="18" rx="5" /><circle cx="12" cy="12" r="4" /><circle cx="17.5" cy="6.5" r=".8" fill="currentColor" /></g></symbol>
      <symbol id="pin" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M12 21s-7-6.2-7-11.5a7 7 0 0 1 14 0C19 14.8 12 21 12 21z" /><circle cx="12" cy="9.5" r="2.5" /></g></symbol>
      <symbol id="bag" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M5 8h14l-1 12H6z" /><path d="M9 8V6a3 3 0 0 1 6 0v2" /></g></symbol>
      <symbol id="plus" viewBox="0 0 24 24"><path stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" d="M12 5v14M5 12h14" /></symbol>
      <symbol id="check" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" d="M5 12.5l4.5 4.5L19 7.5" /></symbol>
      <symbol id="close" viewBox="0 0 24 24"><path stroke="currentColor" strokeWidth="2" strokeLinecap="round" d="M6 6l12 12M18 6L6 18" /></symbol>
      <symbol id="search" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="7" /><path d="M20 20l-4-4" /></g></symbol>
      <symbol id="arrow" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" d="M7 17L17 7M9 7h8v8" /></symbol>
      <symbol id="play" viewBox="0 0 24 24"><path fill="currentColor" d="M7 4l13 8-13 8z" /></symbol>

      <symbol id="z-bozo" viewBox="0 0 24 24">
        <g {...ZONE_STROKE}>
          <path d="M2.6 11.6c1.9-3.2 4.3-5.3 6.4-5.3c1.1 0 1.8.7 2.3 1.6c.3.5.5.8.7.8c.2 0 .4-.3.7-.8c.5-.9 1.2-1.6 2.3-1.6c2.1 0 4.5 2.1 6.4 5.3" />
          <path d="M2.6 11.6c1.6 4.2 4.9 6.9 9.4 6.9c4.5 0 7.8-2.7 9.4-6.9" />
          <path d="M2.6 11.6c3-1.1 6.1-1.6 9.4-1.6c3.3 0 6.4.5 9.4 1.6" />
        </g>
      </symbol>
      <symbol id="z-axilas" viewBox="0 0 24 24">
        <g {...ZONE_STROKE}>
          <path d="M8.4 21.6C7.5 17 8 12.6 9.6 9.4C10.3 8 11.1 7.2 12 6.8C12.9 7.2 13.7 8 14.4 9.4C16 12.6 16.5 17 15.6 21.6z" />
          <path d="M10.2 8.8L6.2 4.4" />
          <path d="M13.8 8.8L17.8 4.4" />
        </g>
      </symbol>
      <symbol id="z-bikini" viewBox="0 0 24 24">
        <g {...ZONE_STROKE}>
          <path d="M4 7h16v2.2c0 3.3-1.4 6.3-3.9 8.5L12 21.2 7.9 17.7C5.4 15.5 4 12.5 4 9.2z" />
          <circle cx="12" cy="5" r="1.1" fill="currentColor" stroke="none" />
        </g>
      </symbol>
      <symbol id="z-piernas" viewBox="0 0 24 24">
        <g {...ZONE_STROKE}>
          <path d="M10.6 3.2c-.8 4.4-1 8.8-.5 13.2.1 1.2.3 2.3.5 3.4" />
          <path d="M13.4 3.2c.8 4.4 1 8.8.5 13.2-.1 1.2-.3 2.3-.5 3.4" />
          <path d="M10.6 19.8c-.9.2-1.7.6-2.3 1.3" />
          <path d="M13.4 19.8c.9.2 1.7.6 2.3 1.3" />
        </g>
      </symbol>
      <symbol id="z-muslos" viewBox="0 0 24 24">
        <g {...ZONE_STROKE}>
          <path d="M4.8 5c1.9 1.3 4.4 2 7.2 2s5.3-.7 7.2-2" />
          <path d="M4.8 5c-.4 3.2.5 6.1 2.3 8.7l1.5 2.1c.6.9 1 2 1.1 3.1l.2 2.4" />
          <path d="M19.2 5c.4 3.2-.5 6.1-2.3 8.7l-1.5 2.1c-.6.9-1 2-1.1 3.1l-.2 2.4" />
          <path d="M12 12.6c-.9 1.8-1.5 3.8-1.7 5.9" />
          <path d="M12 12.6c.9 1.8 1.5 3.8 1.7 5.9" />
        </g>
      </symbol>
    </svg>
  );
}
