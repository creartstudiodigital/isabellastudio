import { laserOptions, ZONE_ICON, type LaserKind, type LaserOption } from "@/lib/salon";
import { img } from "@/lib/salon-images";
import { Icon } from "@/components/salon/Icons";

type Props = {
  isOn: (name: string) => boolean;
  onToggle: (name: string, price: number) => void;
  /** Mujer/hombre tab, kept by the page so the machine photo can follow it. */
  kind: LaserKind;
  onKind: (k: LaserKind) => void;
};

/** Crop of the section photo shown in each package card (background-position x% y%). */
const THUMB: Record<LaserKind, readonly string[]> = {
  mujer: ["44% 24%", "72% 80%", "32% 74%"],
  hombre: ["78% 30%", "30% 96%", "60% 90%"],
};

/** Candela® laser packages (woman/man), each card shows its 4- and 10-session USD prices. */
export function LaserSection({ isOn, onToggle, kind, onKind }: Props) {
  const photo = img(`laser-${kind}`);
  const four = laserOptions(kind, 4);
  const ten = laserOptions(kind, 10);

  const pill = (o: LaserOption | undefined, ses: 4 | 10) => {
    if (!o) return null;
    const on = isOn(o.name);
    return (
      <button
        type="button"
        className={`lzp s${ses}`}
        aria-pressed={on}
        aria-label={`${on ? "Quitar" : "Agregar"} opción ${o.index + 1}, ${ses} sesiones, $${o.price}`}
        onClick={() => onToggle(o.name, o.price)}
      >
        <small>{ses} sesiones</small>
        <b>{on && <Icon id="check" />}${o.price}</b>
        <span>${o.perSession} c/u</span>
      </button>
    );
  };

  return (
    <div className="lz">
      <div className="lz-photo">
        <img src={photo} alt={kind === "mujer" ? "Mujer con piel suave tras depilación láser" : "Hombre con piel suave tras depilación láser"} />
        <span className="lz-seal"><b>Candela®</b>Tecnología láser</span>
      </div>

      <div className="lz-body">
        <h2 className="lz-title">Tu piel <span className="script">sin límites</span></h2>
        <p className="lz-kick">Depilación láser</p>
        <p className="lz-tech">con tecnología <b>Candela®</b></p>

        <div className="lz-bar">
          <div className="seg" role="group" aria-label="Paquete">
            <button type="button" aria-pressed={kind === "mujer"} onClick={() => onKind("mujer")}>Mujer</button>
            <button type="button" aria-pressed={kind === "hombre"} onClick={() => onKind("hombre")}>Hombre</button>
          </div>
          <span className="lz-hint">Toca un precio para agregarlo a tu cita</span>
        </div>

        <div className="lz-cards">
          {four.map((o) => (
            <article className={`lzc${o.best ? " best" : ""}`} key={o.index}>
              <div className="lzc-thumb" style={{ backgroundImage: `url(${photo})`, backgroundPosition: THUMB[kind][o.index] }}>
                <span className="lzc-num">{o.index + 1}</span>
              </div>
              <div className="lzc-mid">
                <h3>{o.zones.join(" + ")}{o.best && <em>Más completo</em>}</h3>
                <ul className="lzc-icons">
                  {o.zones.map((z) => (
                    <li key={z}><i><Icon id={ZONE_ICON[z]} /></i>{z}</li>
                  ))}
                </ul>
              </div>
              <div className="lzc-prices">
                {pill(o, 4)}
                {pill(ten[o.index], 10)}
              </div>
            </article>
          ))}
        </div>
      </div>
    </div>
  );
}
