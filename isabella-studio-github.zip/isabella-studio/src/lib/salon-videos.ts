// Salon reels hosted as Lovable assets, shown in the "Síguenos" video carousel.
import v1 from "@/assets/salon/videos/video1.mp4.asset.json";
import p1 from "@/assets/salon/videos/video1-poster.jpg.asset.json";
import v2 from "@/assets/salon/videos/video2.mp4.asset.json";
import p2 from "@/assets/salon/videos/video2-poster.jpg.asset.json";
import v3 from "@/assets/salon/videos/video3.mp4.asset.json";
import p3 from "@/assets/salon/videos/video3-poster.jpg.asset.json";
import v4 from "@/assets/salon/videos/video4.mp4.asset.json";
import p4 from "@/assets/salon/videos/video4-poster.jpg.asset.json";
import v5 from "@/assets/salon/videos/video5.mp4.asset.json";
import p5 from "@/assets/salon/videos/video5-poster.jpg.asset.json";

export type SalonVideo = { src: string; poster: string; caption: string };

export const VIDEOS: SalonVideo[] = [
  { src: v1.url, poster: p1.url, caption: "Proceso de uñas" },
  { src: v2.url, poster: p2.url, caption: "Estilismo" },
  { src: v3.url, poster: p3.url, caption: "Lifting de pestañas" },
  { src: v4.url, poster: p4.url, caption: "Diseños de uñas" },
  { src: v5.url, poster: p5.url, caption: "Hidratación capilar" },
];
