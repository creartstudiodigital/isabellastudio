// Salon photos hosted as Lovable assets, keyed by their original file stem.
import alisado from "@/assets/salon/alisado.jpg.asset.json";
import balayage from "@/assets/salon/balayage.jpg.asset.json";
import cashea from "@/assets/salon/cashea.jpg.asset.json";
import cejas from "@/assets/salon/cejas.jpg.asset.json";
import cejas2 from "@/assets/salon/cejas2.jpg.asset.json";
import cejas3 from "@/assets/salon/cejas3.jpg.asset.json";
import depilador_hombre from "@/assets/salon/depilador-hombre.webp.asset.json";
import cera from "@/assets/salon/cera.jpg.asset.json";
import frances from "@/assets/salon/frances.jpg.asset.json";
import gentlemax_pro_laser from "@/assets/salon/gentlemax-pro-laser.png.asset.json";
import laminado from "@/assets/salon/laminado.jpg.asset.json";
import laser from "@/assets/salon/laser.jpg.asset.json";
import laser_hombre from "@/assets/salon/laser-hombre.webp.asset.json";
import laser_mujer from "@/assets/salon/laser-mujer.webp.asset.json";
import liso from "@/assets/salon/liso.jpg.asset.json";
import local from "@/assets/salon/local.jpg.asset.json";
import logo_magenta from "@/assets/salon/logo-magenta.png.asset.json";
import mapa from "@/assets/salon/mapa.jpg.asset.json";
import ondas from "@/assets/salon/ondas.jpg.asset.json";
import pedicure from "@/assets/salon/pedicure.jpg.asset.json";
import pedicure2 from "@/assets/salon/pedicure2.webp.asset.json";
import pestanas from "@/assets/salon/pestanas.jpg.asset.json";
import pestanas2 from "@/assets/salon/pestanas2.jpg.asset.json";
import pestanas3 from "@/assets/salon/pestanas3-up.jpg.asset.json";
import pestanas4 from "@/assets/salon/pestanas4.jpg.asset.json";
import pestanas5 from "@/assets/salon/pestanas5.jpg.asset.json";
import rojo from "@/assets/salon/rojo.jpg.asset.json";
import unas from "@/assets/salon/unas.jpg.asset.json";

export const IMG: Record<string, string> = {
  "alisado": alisado.url,
  "balayage": balayage.url,
  "cashea": cashea.url,
  "cejas": cejas.url,
  "cejas2": cejas2.url,
  "cejas3": cejas3.url,
  "depilador-hombre": depilador_hombre.url,
  "cera": cera.url,
  "frances": frances.url,
  "gentlemax-pro-laser": gentlemax_pro_laser.url,
  "laminado": laminado.url,
  "laser": laser.url,
  "laser-hombre": laser_hombre.url,
  "laser-mujer": laser_mujer.url,
  "liso": liso.url,
  "local": local.url,
  "logo-magenta": logo_magenta.url,
  "mapa": mapa.url,
  "ondas": ondas.url,
  "pedicure": pedicure.url,
  "pedicure2": pedicure2.url,
  "pestanas": pestanas.url,
  "pestanas2": pestanas2.url,
  "pestanas3": pestanas3.url,
  "pestanas4": pestanas4.url,
  "pestanas5": pestanas5.url,
  "rojo": rojo.url,
  "unas": unas.url,
};

export const img = (stem: string) => IMG[stem] ?? "";
