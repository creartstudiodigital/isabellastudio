// Isa'Bella Studio business data: service menu, laser packages and the
// "Mi cita" (appointment builder) rules that compose the WhatsApp message.

export const WA_NUMBER = "584129501196";
export const WA_PHONE_LABEL = "0412-950 1196";
export const WA_BASE = `https://wa.me/${WA_NUMBER}?text=`;
export const waLink = (text: string) => WA_BASE + encodeURIComponent(text);
export const INSTAGRAM_URL = "https://instagram.com/isabellastudior";
export const TIKTOK_URL = "https://www.tiktok.com/@isabellastudior";
export const HANDLE = "@isabellastudior";
export const MAPS_SALON_URL =
  "https://www.google.com/maps/search/?api=1&query=Isa'Bella+Studio+Calle+L%C3%B3pez+Aveledo+Calicanto+Maracay";
export const MAPS_ADDRESS_URL =
  "https://www.google.com/maps/search/?api=1&query=Calle+L%C3%B3pez+Aveledo+Calicanto+Maracay";

export type Service = readonly [name: string, price: number];
export type ServiceGroup = readonly [title: string, items: readonly Service[]];
export type Category = {
  id: string;
  name: string;
  sub: string;
  img: string;
  groups: readonly ServiceGroup[];
};

export const CATS: readonly Category[] = [
  {
    id: "unas", name: "Uñas", sub: "Manicure y pedicure", img: "unas",
    groups: [
      ["Semipermanente", [["Manicure semipermanente", 18], ["Pedicure semipermanente", 18], ["Manicure y pedicure semipermanente", 27], ["Manicure nivelación semipermanente", 24], ["Manicure semipermanente y pedicure tradicional", 24], ["Manicure nivelación y pedicure semipermanente", 32]]],
      ["Tradicional & caballeros", [["Manicure tradicional", 16], ["Pedicure tradicional", 16], ["Manicure y pedicure tradicional", 22], ["Limpieza de manicure y pedicure de dama", 20], ["Manicure de caballero", 23], ["Pedicure de caballero", 23], ["Manicure y pedicure de caballero", 30]]],
      ["Sistemas", [["Sistema acrílico", 35], ["Sistema jelly", 30], ["Kaping poly gel", 35], ["Sistema y pedicure semipermanente", 45], ["Sistema y pedicure tradicional", 43], ["Kaping y pedicure semipermanente", 45], ["Kaping y pedicure tradicional", 43]]],
      ["Extras", [["Cambio de esmalte tradicional", 5], ["Cambio de esmalte semipermanente", 8], ["Retiro de sistema", 5], ["Retiro de semipermanente", 3], ["Pincelada", 4], ["Diseño", 6], ["Hidratación con parafina", 15]]],
    ],
  },
  {
    id: "estilismo", name: "Estilismo", sub: "Cortes, color y peinados", img: "balayage",
    groups: [
      ["Secado & cortes", [["Secado cabello corto", 15], ["Secado cabello medio", 20], ["Secado cabello largo", 25], ["Secado cabello extra largo", 30], ["Secado cabello largo con extensiones", 35], ["Corte elaborado", 15], ["Corte de puntas", 10]]],
      ["Lavado & tinte", [["Lavado sencillo", 8], ["Lavado Wella", 15], ["Lavado de químico", 15], ["Lavado y matiz con shampoo", 15], ["Lavado y matiz", 35], ["Aplicación de tinte con producto", 60], ["Aplicación de tinte sin producto", 45]]],
      ["Hidratación & peinado", [["Hidratación capilar cabello corto", 25], ["Hidratación capilar cabello medio", 30], ["Hidratación capilar cabello largo", 35], ["Hidratación capilar cabello extra largo", 45], ["Hidratación Isa'Bella", 30], ["Hidratación Wella", 50], ["Hidratación post tratamiento", 50], ["Alisado OZ", 50], ["Peinado recogido", 40], ["Peinado semi recogido", 35], ["Ondas", 20]]],
    ],
  },
  {
    id: "cejas", name: "Cejas", sub: "Diseño, pigmento y laminado", img: "laminado",
    groups: [["Cejas", [["Cejas epiladas", 6], ["Cejas pigmentadas", 6], ["Cejas epiladas y pigmentadas", 10], ["Laminado de cejas", 25]]]],
  },
  {
    id: "pestanas", name: "Pestañas", sub: "Lifting y extensiones", img: "pestanas2",
    groups: [["Pestañas & retiro", [["Lifting de pestañas", 25], ["Pestañas clásicas", 20], ["Pestañas efecto rímel", 25], ["Pestañas tecnológicas", 28], ["Pestañas volumen ruso", 30], ["Retiro de pestañas", 5]]]],
  },
  {
    id: "epilacion", name: "Epilación", sub: "Cera facial y corporal", img: "cera",
    groups: [["Facial & corporal", [["Epilación facial", 5], ["Bozo", 4], ["Mentón", 4], ["Axilas", 15], ["Brasilera", 25], ["Media pierna", 20], ["Pierna completa", 30], ["Línea alba", 10]]]],
  },
];

export const ZONES = ["Bozo", "Axilas", "Bikini", "Piernas", "Muslos"] as const;
export type Zone = (typeof ZONES)[number];

/** Pictogram shown next to each zone chip in the laser options. */
export const ZONE_ICON: Record<Zone, IconId> = {
  Bozo: "z-bozo",
  Axilas: "z-axilas",
  Bikini: "z-bikini",
  Piernas: "z-piernas",
  Muslos: "z-muslos",
};

export type LaserKind = "mujer" | "hombre";
export type LaserSessions = 4 | 10;
/** USD price per option: [4 sessions, 10 sessions]. */
export const LASER: Record<LaserKind, readonly (readonly [number, number])[]> = {
  mujer: [[100, 200], [150, 300], [200, 400]],
  hombre: [[130, 260], [200, 400], [250, 500]],
};

import type { IconId } from "@/components/salon/Icons";

export type LaserOption = { index: number; zones: Zone[]; price: number; perSession: number; name: string; best: boolean };

export function laserOptions(kind: LaserKind, ses: LaserSessions): LaserOption[] {
  return LASER[kind].map((pair, i) => {
    const price = ses === 4 ? pair[0] : pair[1];
    return {
      index: i,
      zones: ZONES.slice(0, 3 + i),
      price,
      perSession: Math.round(price / ses),
      name: `Láser ${kind === "mujer" ? "Mujer" : "Hombre"} opción ${i + 1} · ${ses} sesiones`,
      best: i === 2,
    };
  });
}

export const minPrice = (c: Category) => Math.min(...c.groups.flatMap((g) => g[1].map((i) => i[1])));
export const serviceCount = (c: Category) => c.groups.reduce((a, g) => a + g[1].length, 0);

/** Lowercase and strip accents so "unas" finds "Uñas"-style matches. */
export const norm = (s: string) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

export type Currency = "€" | "$";
export type CitaItem = { name: string; price: number; cur: Currency };

export const fmtPrice = (p: number, cur: Currency) => (cur === "$" ? `$${p}` : `${p} €`);

/** Services are priced in euros, laser packages in dollars; totals are kept separate. */
export function citaTotal(items: readonly CitaItem[]): string {
  const eur = items.filter((i) => i.cur === "€").reduce((a, i) => a + i.price, 0);
  const usd = items.filter((i) => i.cur === "$").reduce((a, i) => a + i.price, 0);
  return [eur ? `${eur} €` : "", usd ? `$${usd}` : ""].filter(Boolean).join(" + ") || "0 €";
}

export function citaWhatsAppUrl(items: readonly CitaItem[]): string {
  if (!items.length) return waLink("Hola Isa'Bella Studio, quiero reservar una cita");
  const msg =
    "Hola Isa'Bella Studio, quiero reservar:\n" +
    items.map((i) => `• ${i.name} (${fmtPrice(i.price, i.cur)})`).join("\n") +
    "\nTotal estimado: " +
    citaTotal(items);
  return waLink(msg);
}

export const HERO_SLIDES: readonly (readonly [img: string, caption: string])[] = [
  ["alisado", "Alisado y brillo"], ["unas", "Manicure francés dorado"], ["frances", "Manicure francés clásico"], ["rojo", "Color rojo intenso"],
  ["pestanas4", "Cejas laminadas y pestañas naturales"], ["pestanas2", "Pestañas clásicas"], ["ondas", "Mechas con ondas"], ["pedicure2", "Pedicure francés"],
  ["laminado", "Laminado de cejas"], ["cejas3", "Cejas y pestañas"], ["balayage", "Balayage"], ["pedicure", "Pedicure semipermanente"],
  ["cejas2", "Cejas pigmentadas"], ["pestanas5", "Lifting de pestañas"], ["liso", "Cabello largo liso"], ["local", "Nuestro local en Calicanto"],
];

export const RIBBON_WORDS = ["Manicure", "Pedicure", "Sistema acrílico", "Kaping poly gel", "Alisado OZ", "Hidratación Wella", "Peinados", "Laminado de cejas", "Pestañas volumen ruso", "Láser Candela®", "Cashea sin intereses"];

