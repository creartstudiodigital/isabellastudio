import { render } from "@testing-library/react";
import { createElement } from "react";
import { describe, expect, it } from "vitest";
import { CATS, citaTotal, citaWhatsAppUrl, HERO_SLIDES, laserOptions, minPrice, ZONE_ICON, ZONES } from "@/lib/salon";
import { img } from "@/lib/salon-images";
import { VIDEOS } from "@/lib/salon-videos";
import { SvgSprite } from "@/components/salon/Icons";

describe("Isa'Bella Studio pricing rules", () => {
  it("shows the cheapest price per specialty (Uñas desde 3 €)", () => {
    const unas = CATS.find((c) => c.id === "unas");
    expect(unas && minPrice(unas)).toBe(3);
  });

  it("prices women's laser option 3 at $200 for 4 sessions ($50 each)", () => {
    const opt = laserOptions("mujer", 4)[2];
    expect(opt?.price).toBe(200);
    expect(opt?.perSession).toBe(50);
    expect(opt?.zones).toEqual(["Bozo", "Axilas", "Bikini", "Piernas", "Muslos"]);
  });

  it("prices men's laser option 1 at $260 for 10 sessions", () => {
    expect(laserOptions("hombre", 10)[0]?.price).toBe(260);
  });

  it("draws a pictogram for every laser zone chip", () => {
    const sprite = render(createElement(SvgSprite)).container;
    for (const zone of ZONES) {
      const iconId = ZONE_ICON[zone];
      expect(sprite.querySelector(`symbol#${iconId}`)).not.toBeNull();
    }
    for (const opt of [...laserOptions("mujer", 4), ...laserOptions("hombre", 10)]) {
      expect(opt.zones.every((z) => ZONE_ICON[z])).toBe(true);
    }
  });

  it("keeps euro services and dollar laser packages in separate totals", () => {
    expect(
      citaTotal([
        { name: "Manicure semipermanente", price: 18, cur: "€" },
        { name: "Laminado de cejas", price: 25, cur: "€" },
        { name: "Láser Mujer opción 1 · 4 sesiones", price: 100, cur: "$" },
      ]),
    ).toBe("43 € + $100");
    expect(citaTotal([])).toBe("0 €");
  });

  it("sends the cita to the salon's WhatsApp 584129501196 with the item list", () => {
    const url = citaWhatsAppUrl([{ name: "Bozo", price: 4, cur: "€" }]);
    expect(url.startsWith("https://wa.me/584129501196?text=")).toBe(true);
    expect(decodeURIComponent(url.split("text=")[1] ?? "")).toBe(
      "Hola Isa'Bella Studio, quiero reservar:\n• Bozo (4 €)\nTotal estimado: 4 €",
    );
  });

  it("shows the new brows-and-lashes photo where the volume-lash photo was", () => {
    expect(HERO_SLIDES.some(([f]) => f === "pestanas")).toBe(false);
    expect(HERO_SLIDES.some(([f, c]) => f === "pestanas4" && c === "Cejas laminadas y pestañas naturales")).toBe(true);
    expect(img("pestanas4")).toContain("pestanas4.jpg");
    for (const [f] of HERO_SLIDES) expect(img(f)).toBeTruthy();
  });

  it("shows the uploaded brows-and-lashes photo in the 'Cejas y pestañas' cover slide", () => {
    expect(HERO_SLIDES.some(([f, c]) => f === "cejas3" && c === "Cejas y pestañas")).toBe(true);
    expect(HERO_SLIDES.some(([f, c]) => f === "cejas" && c === "Cejas y pestañas")).toBe(false);
    expect(img("cejas3")).toContain("cejas3.jpg");
  });

  it("shows the lash-lift photo in the 'Lifting de pestañas' cover slide", () => {
    expect(HERO_SLIDES.some(([f, c]) => f === "pestanas5" && c === "Lifting de pestañas")).toBe(true);
    expect(HERO_SLIDES.some(([f]) => f === "pestanas3")).toBe(false);
    expect(img("pestanas5")).toContain("pestanas5.jpg");
  });

  it("has the laser machine photo available for the laser section", () => {
    expect(img("gentlemax-pro-laser")).toContain("gentlemax-pro-laser.png");
  });

  it("has its own machine photo for the man laser tab", () => {
    expect(img("depilador-hombre")).toContain("depilador-hombre.webp");
    expect(img("depilador-hombre")).not.toBe(img("gentlemax-pro-laser"));
  });

  it("shows the 5 salon videos in the Síguenos carousel, each with its cover", () => {
    expect(VIDEOS).toHaveLength(5);
    for (const v of VIDEOS) {
      expect(v.src).toMatch(/\.mp4$/);
      expect(v.poster).toMatch(/\.jpg$/);
    }
  });
});
